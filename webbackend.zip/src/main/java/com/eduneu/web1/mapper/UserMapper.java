package com.eduneu.web1.mapper;

import com.eduneu.web1.entity.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {
    // 登录
    @Select("SELECT * FROM user WHERE username = #{username} AND password = #{password}")
    User login(User user);

    // 获取所有用户
    @Select("SELECT * FROM user")
    List<User> findAllUsers();

    // 条件查询用户
    @Select("SELECT * FROM user WHERE username LIKE CONCAT('%', #{username}, '%') " +
            "OR telephone LIKE CONCAT('%', #{telephone}, '%') " +
            "OR status = #{status}")
    List<User> findUsersByCondition(@Param("username") String username,
                                    @Param("telephone") String telephone,
                                    @Param("status") Integer status);

    // 删除用户
    @Delete("DELETE FROM user WHERE uid = #{uid}")
    int deleteUser(@Param("uid") Long uid);

    // 添加用户
    @Insert("INSERT INTO user(username, password, nickname, telephone, email, gender, status, role, company_id, create_time) " +
            "VALUES(#{username}, #{password}, #{nickname}, #{telephone}, #{email}, #{gender}, #{status}, #{role}, #{companyId}, #{createTime})")
    @Options(useGeneratedKeys = true, keyProperty = "uid")
    int insertUser(User user);

    // 更新用户
    @Update("UPDATE user SET username=#{username}, nickname=#{nickname}, telephone=#{telephone}, " +
            "email=#{email}, gender=#{gender}, update_time=#{updateTime} WHERE uid=#{uid}")
    int updateUser(User user);

    // 修改密码
    @Update("UPDATE user SET password = #{newPassword} WHERE uid = #{uid} AND password = #{oldPassword}")
    int updatePassword(@Param("uid") Long uid,
                       @Param("oldPassword") String oldPassword,
                       @Param("newPassword") String newPassword);

    // 根据ID查询用户
    @Select("SELECT * FROM user WHERE uid = #{uid}")
    User findUserById(@Param("uid") Long uid);
}