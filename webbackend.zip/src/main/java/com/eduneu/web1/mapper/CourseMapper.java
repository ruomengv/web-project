package com.eduneu.web1.mapper;
import  com.eduneu.web1.entity.Course;

import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CourseMapper {
    @Insert("INSERT INTO course(title, cover, summary, sort, video_url, author, status, creator_id, reject_reason) " +
            "VALUES(#{title}, #{cover}, #{summary}, #{sort}, #{videoUrl}, #{author}, #{status}, #{creatorId}, #{rejectReason})")
    int insertCourse(Course course);

    @Update("UPDATE course SET title=#{title}, cover=#{cover}, summary=#{summary}, " +
            "sort=#{sort}, video_url=#{videoUrl}, author=#{author}, status=#{status}, reject_reason=#{rejectReason} " +
            "WHERE id=#{id}")
    int updateCourse(Course course);

    @Delete("DELETE FROM course WHERE id=#{id}")
    int deleteCourse(Long id);

    @Select("SELECT * FROM course WHERE id=#{id}")
    Course findCourseById(Long id);

    @Select("SELECT * FROM course")
    List<Course> findAllCourses();

    @Select("SELECT * FROM course WHERE title LIKE CONCAT('%', #{keyword}, '%') " +
            "OR author LIKE CONCAT('%', #{keyword}, '%')")
    List<Course> searchCourses(String keyword);

    @Select("SELECT * FROM course WHERE status=0")
    List<Course> findPendingCourses();
}