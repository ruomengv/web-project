package com.eduneu.web1.mapper;
import  com.eduneu.web1.entity.News;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface NewsMapper {
    @Insert("INSERT INTO news(title, cover, summary, content, author, status, creator_id, reject_reason) " +
            "VALUES(#{title}, #{cover}, #{summary}, #{content}, #{author}, #{status}, #{creatorId}, #{rejectReason})")
    int insertNews(News news);

    @Update("UPDATE news SET title=#{title}, cover=#{cover}, summary=#{summary}, content=#{content}, " +
            "author=#{author}, status=#{status}, reject_reason=#{rejectReason} WHERE id=#{id}")
    int updateNews(News news);

    @Delete("DELETE FROM news WHERE id=#{id}")
    int deleteNews(Long id);

    @Select("SELECT * FROM news WHERE id=#{id}")
    News findNewsById(Long id);

    @Select("SELECT * FROM news WHERE creator_id=#{creatorId}")
    List<News> findNewsByCreator(Long creatorId);

    @Select("SELECT * FROM news WHERE status=0")
    List<News> findPendingNews();

    @Select("SELECT * FROM news WHERE title LIKE CONCAT('%', #{keyword}, '%') " +
            "OR author LIKE CONCAT('%', #{keyword}, '%') " +
            "OR summary LIKE CONCAT('%', #{keyword}, '%')")
    List<News> searchNews(String keyword);
}