package com.eduneu.web1.controller;

import com.eduneu.web1.dto.PasswordDTO;
import com.eduneu.web1.entity.User;
import com.eduneu.web1.mapper.UserMapper;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController

@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserMapper userMapper;

    // 获取当前用户
    private User getCurrentUser(HttpSession session) {
        return (User) session.getAttribute("currentUser");
    }

    // 获取当前用户信息
    @GetMapping("/profile")
    public User getProfile(HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            throw new RuntimeException("用户未登录");
        }
        return userMapper.findUserById(currentUser.getUid());
    }

    // 更新个人信息
    @PutMapping("/profile")
    public int updateProfile(@RequestBody User user, HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            throw new RuntimeException("用户未登录");
        }

        // 只能更新自己的信息
        user.setUid(currentUser.getUid());
        user.setUpdateTime(new Date());
        return userMapper.updateUser(user);
    }

    // 修改密码
    @PutMapping("/password")
    public int changePassword(@RequestBody PasswordDTO dto, HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            throw new RuntimeException("用户未登录");
        }

        // 只能修改自己的密码
        dto.setUid(currentUser.getUid());
        return userMapper.updatePassword(dto.getUid(), dto.getOldPassword(), dto.getNewPassword());
    }

    // 用户列表（管理员）
    @GetMapping("/list")
    public List<User> listUsers(@RequestParam(required = false) String username,
                                @RequestParam(required = false) String telephone,
                                @RequestParam(required = false) Integer status,
                                HttpSession session) {
        // 检查管理员权限
        User currentUser = getCurrentUser(session);
        if (currentUser == null || currentUser.getRole() != 0) {
            throw new RuntimeException("无管理员权限");
        }

        return userMapper.findUsersByCondition(username, telephone, status);
    }

    // 创建用户（管理员）
    @PostMapping
    public int createUser(@RequestBody User user, HttpSession session) {
        // 检查管理员权限
        User currentUser = getCurrentUser(session);
        if (currentUser == null || currentUser.getRole() != 0) {
            throw new RuntimeException("无管理员权限");
        }

        user.setCreateTime(new Date());
        return userMapper.insertUser(user);
    }

    // 更新用户（管理员）
    @PutMapping("/admin/{uid}")
    public int adminUpdateUser(@PathVariable Long uid, @RequestBody User user, HttpSession session) {
        // 检查管理员权限
        User currentUser = getCurrentUser(session);
        if (currentUser == null || currentUser.getRole() != 0) {
            throw new RuntimeException("无管理员权限");
        }

        user.setUid(uid);
        user.setUpdateTime(new Date());
        return userMapper.updateUser(user);
    }

    // 删除用户（管理员）
    @DeleteMapping("/admin/{uid}")
    public int deleteUser(@PathVariable Long uid, HttpSession session) {
        // 检查管理员权限
        User currentUser = getCurrentUser(session);
        if (currentUser == null || currentUser.getRole() != 0) {
            throw new RuntimeException("无管理员权限");
        }

        return userMapper.deleteUser(uid);
    }
}