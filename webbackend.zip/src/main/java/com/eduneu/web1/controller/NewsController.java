package com.eduneu.web1.controller;

import com.eduneu.web1.entity.News;
import com.eduneu.web1.entity.User;
import com.eduneu.web1.mapper.NewsMapper;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController

@RequestMapping("/api/news")
public class NewsController {

    @Autowired
    private NewsMapper newsMapper;

    // 获取当前用户
    private User getCurrentUser(HttpSession session) {
        return (User) session.getAttribute("currentUser");
    }

    // 发布动态
    @PostMapping
    public int createNews(@RequestBody News news, HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            throw new RuntimeException("用户未登录");
        }

        // 超级管理员直接发布，企业用户需要审核
        news.setStatus(currentUser.getRole() == 0 ? 1 : 0);
        news.setCreatorId(currentUser.getUid());
        return newsMapper.insertNews(news);
    }

    // 更新动态
    @PutMapping("/{id}")
    public int updateNews(@PathVariable Long id, @RequestBody News news,
                          HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            throw new RuntimeException("用户未登录");
        }

        News existing = newsMapper.findNewsById(id);

        // 权限检查：超级管理员或创建者本人
        if (currentUser.getRole() != 0 && !existing.getCreatorId().equals(currentUser.getUid())) {
            throw new RuntimeException("无权限操作此动态");
        }

        news.setId(id);
        // 如果是企业用户更新，重置为待审核状态
        if (currentUser.getRole() != 0) {
            news.setStatus(0);
        }
        return newsMapper.updateNews(news);
    }

    // 删除动态
    @DeleteMapping("/{id}")
    public int deleteNews(@PathVariable Long id, HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            throw new RuntimeException("用户未登录");
        }

        News existing = newsMapper.findNewsById(id);
        // 权限检查：超级管理员或创建者本人
        if (currentUser.getRole() != 0 && !existing.getCreatorId().equals(currentUser.getUid())) {
            throw new RuntimeException("无权限操作此动态");
        }
        return newsMapper.deleteNews(id);
    }

    // 获取用户动态列表
    @GetMapping
    public List<News> listUserNews(@RequestParam Long creatorId) {
        return newsMapper.findNewsByCreator(creatorId);
    }

    // 搜索动态
    @GetMapping("/search")
    public List<News> searchNews(@RequestParam String keyword) {
        return newsMapper.searchNews(keyword);
    }

    // 动态详情
    @GetMapping("/{id}")
    public News getNewsDetail(@PathVariable Long id) {
        return newsMapper.findNewsById(id);
    }
}