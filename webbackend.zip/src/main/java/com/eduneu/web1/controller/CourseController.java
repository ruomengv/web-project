package com.eduneu.web1.controller;

import com.eduneu.web1.entity.Course;
import com.eduneu.web1.entity.User;
import com.eduneu.web1.mapper.CourseMapper;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController

@RequestMapping("/api/courses")
public class CourseController {

    @Autowired
    private CourseMapper courseMapper;

    // 获取当前用户
    private User getCurrentUser(HttpSession session) {
        return (User) session.getAttribute("currentUser");
    }

    // 添加课程
    @PostMapping
    public int createCourse(@RequestBody Course course, HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            throw new RuntimeException("用户未登录");
        }

        // 超级管理员直接发布，企业用户需要审核
        course.setStatus(currentUser.getRole() == 0 ? 1 : 0);
        course.setCreatorId(currentUser.getUid());
        return courseMapper.insertCourse(course);
    }

    // 更新课程
    @PutMapping("/{id}")
    public int updateCourse(@PathVariable Long id, @RequestBody Course course,
                            HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            throw new RuntimeException("用户未登录");
        }

        Course existing = courseMapper.findCourseById(id);

        // 权限检查：超级管理员或创建者本人
        if (currentUser.getRole() != 0 && !existing.getCreatorId().equals(currentUser.getUid())) {
            throw new RuntimeException("无权限操作此课程");
        }

        course.setId(id);
        // 如果是企业用户更新，重置为待审核状态
        if (currentUser.getRole() != 0) {
            course.setStatus(0);
        }
        return courseMapper.updateCourse(course);
    }

    // 删除课程
    @DeleteMapping("/{id}")
    public int deleteCourse(@PathVariable Long id, HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            throw new RuntimeException("用户未登录");
        }

        Course existing = courseMapper.findCourseById(id);
        // 权限检查：超级管理员或创建者本人
        if (currentUser.getRole() != 0 && !existing.getCreatorId().equals(currentUser.getUid())) {
            throw new RuntimeException("无权限操作此课程");
        }
        return courseMapper.deleteCourse(id);
    }

    // 课程列表
    @GetMapping
    public List<Course> listCourses() {
        return courseMapper.findAllCourses();
    }

    // 搜索课程
    @GetMapping("/search")
    public List<Course> searchCourses(@RequestParam String keyword) {
        return courseMapper.searchCourses(keyword);
    }

    // 课程详情
    @GetMapping("/{id}")
    public Course getCourseDetail(@PathVariable Long id) {
        return courseMapper.findCourseById(id);
    }
}