// meetingManagementRoutes.js
import MeetingManagement from "/src/views/meeting-management/MeetingManagement.vue";
import AddMeeting from "/src/views/meeting-management/AddMeeting.vue";
import EditMeeting from "/src/views/meeting-management/EditMeeting.vue";

const routes = [
    {
        path: '/Meeting',
        name: 'MeetingManagement',
        component: MeetingManagement
    },
    {
        path: '/Meeting/add',
        name: 'AddMeeting',
        component: AddMeeting
    },
    {
        path: '/Meeting/edit/:id',
        name: 'EditMeeting',
        component: EditMeeting
    }
];

export default routes;