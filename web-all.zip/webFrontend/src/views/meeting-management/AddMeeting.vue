<template>
  <el-form :model="meeting" label-width="120px" @submit.native.prevent="submitForm">
    <el-form-item label="会议名称">
      <el-input v-model="meeting.name"></el-input>
    </el-form-item>
    <el-form-item label="创建人">
      <el-input v-model="meeting.organizer"></el-input>
    </el-form-item>
    <el-form-item label="开始时间">
      <el-date-picker v-model="meeting.startTime" type="datetime" placeholder="选择时间"></el-date-picker>
    </el-form-item>
    <el-form-item label="结束时间">
      <el-date-picker v-model="meeting.endTime" type="datetime" placeholder="选择时间"></el-date-picker>
    </el-form-item>
    <el-form-item label="会议内容">
      <el-input type="textarea" v-model="meeting.content"></el-input>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submitForm">确定</el-button>
      <el-button @click="cancel">取消</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex';

export default {
  name: 'AddMeeting',
  data() {
    return {
      meeting: {
        name: '',
        organizer: '',
        startTime: '',
        endTime: '',
        content: '',
        status: 'Scheduled' // 确保状态为 'Scheduled'
      }
    };
  },
  methods: {
    ...mapActions('meetingManagement', ['createMeeting']),
    async submitForm() {
      try {
        await this.createMeeting(this.meeting);
        this.$router.push({ name: 'MeetingManagement' });
      } catch (error) {
        console.error('Failed to create meeting:', error);
      }
    },
    cancel() {
      this.$router.push({ name: 'MeetingManagement' });
    }
  }
};
</script>