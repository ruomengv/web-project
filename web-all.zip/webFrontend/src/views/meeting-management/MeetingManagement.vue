<template>
  <div class="meeting-management">
    <div class="header">
      <el-input v-model="searchName" placeholder="会议名称" class="search-input"></el-input>
      <el-input v-model="searchOrganizer" placeholder="创建人" class="search-input"></el-input>
      <el-date-picker v-model="searchStartTime" type="datetime" placeholder="开始时间" class="search-input"></el-date-picker>
      <el-button type="primary" @click="search">搜索</el-button>
      <el-button type="primary" @click="goToAddMeeting">添加会议</el-button>
    </div>
    <el-table :data="allMeetings" style="width: 100%">
      <el-table-column prop="id" label="会议ID" width="80"></el-table-column>
      <el-table-column prop="name" label="会议名称"></el-table-column>
      <el-table-column prop="organizer" label="组织者"></el-table-column>
      <el-table-column prop="startTime" label="开始时间"></el-table-column>
      <el-table-column prop="endTime" label="结束时间"></el-table-column>
      <el-table-column prop="status" label="状态"></el-table-column>
      <el-table-column label="操作" width="180">
        <template #default="scope">
          <el-button @click="editMeeting(scope.row.id)" type="text">修改</el-button>
          <el-button @click="confirmDelete(scope.row.id)" type="text" class="delete-button">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[10, 20, 30, 40]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
    ></el-pagination>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';
import axios from 'axios';
import MeetingService from "@services/meetingService.js";
import MeetingManagement from "@store/meetingManagement.js";
import meetingManagement from "@store/meetingManagement.js";

export default {
  name: 'MeetingManagement',
  data() {
    return {
      currentPage: 1,
      pageSize: 10,
      total: 0,
      searchName: '',
      searchOrganizer: '',
      searchStartTime: null,
      allMeeting:''
    };
  },
  computed: {
    ...mapGetters('meetingManagement', ['allMeetings'])
  },
  methods: {
    ...mapActions('meetingManagement', ['fetchMeetings', 'searchMeetings', 'deleteMeeting']),
    goToAddMeeting() {
      this.$router.push({ name: 'AddMeeting' });
    },
    editMeeting(id) {
      this.$router.push({ name: 'EditMeeting', params: { id } });
    },
    confirmDelete(id) {
      this.$confirm(
          '是否确认删除会议管理编号为 "' + id + '" 的数据项?',
          '系统提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }
      )
          .then(() => {
            this.deleteMeeting(id).then(() => {
              this.fetchMeetings();
            });
          })
          .catch(() => {});
    },
    handleSizeChange(val) {
      this.pageSize = val;
      this.fetchMeetings();
    },
    handleCurrentChange(val) {
      this.currentPage = val;
      this.fetchMeetings();
    },
    search() {
      const params = {
        name: this.searchName,
        organizer: this.searchOrganizer,
        startTime: this.searchStartTime ? this.searchStartTime.toISOString() : null
      };
      this.allMeeting = this.searchMeetings(params)
    },
    exportMeetings() {
      axios
          .post(
              '/api/meetings/export',
              {
                name: this.searchName,
                organizer: this.searchOrganizer,
                startTime: this.searchStartTime ? this.searchStartTime.toISOString() : null
              },
              { responseType: 'blob' }
          )
          .then(response => {
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', 'meetings.xlsx');
            document.body.appendChild(link);
            link.click();
          })
          .catch(error => {
            console.error('导出失败', error);
          });
    }
  },
  mounted() {
    this.fetchMeetings();
  }
};
</script>

<style scoped>
.meeting-management {
  padding: 20px;
  background-color: #f5f5f5;
  border-radius: 8px;
}
.header {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 20px;
}
.search-input {
  margin-right: 10px;
}
.el-button {
  margin-right: 10px;
}
.el-table {
  background-color: #fff;
  border-radius: 8px;
  overflow: hidden;
}
.el-pagination {
  margin-top: 20px;
  text-align: center;
}
.delete-button {
  color: #f56c6c;
}
.delete-button:hover {
  color: #ff7875;
}
</style>