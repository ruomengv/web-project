<template>
  <el-form :model="meeting" label-width="120px" @submit.native.prevent="submitForm">
    <el-form-item label="会议名称">
      <el-input v-model="meeting.name"></el-input>
    </el-form-item>
    <el-form-item label="创建人">
      <el-input v-model="meeting.organizer"></el-input>
    </el-form-item>
    <el-form-item label="开始时间">
      <el-date-picker v-model="meeting.startTime" type="datetime" placeholder="选择时间"></el-date-picker>
    </el-form-item>
    <el-form-item label="结束时间">
      <el-date-picker v-model="meeting.endTime" type="datetime" placeholder="选择时间"></el-date-picker>
    </el-form-item>
    <el-form-item label="会议内容">
      <el-input type="textarea" v-model="meeting.content"></el-input>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submitForm">确定</el-button>
      <el-button @click="cancel">取消</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';

export default {
  name: 'EditMeeting',
  data() {
    return {
      meeting: {
        id: '',
        name: '',
        organizer: '',
        startTime: '',
        endTime: '',
        content: '',
        status: 'Active'
      }
    };
  },
  computed: {
    ...mapGetters('meetingManagement', ['currentMeeting'])
  },
  methods: {
    ...mapActions('meetingManagement', ['fetchMeetingById', 'editMeeting']),
    async submitForm() {
      await this.editMeeting(this.meeting);
      this.$router.push({ name: 'MeetingManagement' });
    },
    cancel() {
      this.$router.push({ name: 'MeetingManagement' });
    }
  },
  async mounted() {
    await this.fetchMeetingById(this.$route.params.id);
    Object.assign(this.meeting, this.currentMeeting);
  }
};
</script>