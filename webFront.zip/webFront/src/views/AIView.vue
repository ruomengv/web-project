

<template>
  <iframe
      src="http://localhost/chatbot/twUvH31WQ6TjF33a"
      style="width: 100%; height: 100%; min-height: 700px"
      frameborder="0"
      allow="microphone">
  </iframe>
</template>

<script setup>

</script>

<style scoped>

</style>